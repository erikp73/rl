﻿<?php 
$upload_services[]="filezy.net_member";
$max_file_size["filezy.net_member"]= 10240;
$page_upload["filezy.net_member"] = "filezy.net_member.php";  
?>