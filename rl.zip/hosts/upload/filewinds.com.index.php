﻿<?php 
$upload_services[]="filewinds.com";
$max_file_size["filewinds.com"]=1024;
$page_upload["filewinds.com"] = "filewinds.com.php";  
?>