<?php
$upload_services[]="filesavr.com";
$max_file_size["filesavr.com"]=10000;
$page_upload["filesavr.com"] = "filesavr.com.php";  
?>