<?php
$upload_services[]="extabit.com_free";
$max_file_size["extabit.com_free"]=2048;
$page_upload["extabit.com_free"] = "extabit.com_free.php";  
?>