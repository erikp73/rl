<?php
$upload_services[]="imagehost.org";
$max_file_size["imagehost.org"]=100;
$page_upload["imagehost.org"] = "imagehost.org.php";  
?>