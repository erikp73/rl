<?php
$upload_services[] = "filedino.com";
$max_file_size["filedino.com"] = 400;
$page_upload["filedino.com"] = "filedino.com.php";  
?>