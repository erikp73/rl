<?php
$upload_services[]="megafile.uz";
$max_file_size["megafile.uz"]=100;
$page_upload["megafile.uz"] = "megafile.uz.php";  
?>