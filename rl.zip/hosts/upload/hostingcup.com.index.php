<?
$upload_services[]="hostingcup.com";
$max_file_size["hostingcup.com"]=500;
$page_upload["hostingcup.com"] = "hostingcup.com.php";
?>