<?php
$upload_services[]="metahyper.com_member";
$max_file_size["metahyper.com_member"]=1000;
$page_upload["metahyper.com_member"] = "metahyper.com_member.php";  
?>