<?php
$upload_services[]="jumbofiles.com_member";
$max_file_size["jumbofiles.com_member"]=1000;
$page_upload["jumbofiles.com_member"] = "jumbofiles.com_member.php";  
?>