<?php
$upload_services[]="cinshare.com";
$max_file_size["cinshare.com"]=100;
$page_upload["cinshare.com"] = "cinshare.com.php";  
?>