﻿<?php 
$upload_services[]="fileape.com";
$max_file_size["fileape.com"]=2048;
$page_upload["fileape.com"] = "fileape.com.php";  
?>
