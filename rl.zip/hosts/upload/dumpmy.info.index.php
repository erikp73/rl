<?php
$upload_services[]="dumpmy.info";
$max_file_size["dumpmy.info"]=100;
$page_upload["dumpmy.info"] = "dumpmy.info.php";  
?>