<?php
$upload_services[]="hostingbulk.com_member";
$max_file_size["hostingbulk.com_member"] = 1024;
$page_upload["hostingbulk.com_member"] = "hostingbulk.com_member.php";  
?>