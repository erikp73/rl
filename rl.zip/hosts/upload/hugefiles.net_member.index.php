﻿<?php 
$upload_services[]="hugefiles.net_member";
$max_file_size["hugefiles.net_member"]=5000;
$page_upload["hugefiles.net_member"] = "hugefiles.net_member.php";  
?>