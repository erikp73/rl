﻿<?php 

$upload_services[] = "filesflash.com_member";

$max_file_size["filesflash.com_member"] = 10240;

$page_upload["filesflash.com_member"] = "filesflash.com_member.php";

?>