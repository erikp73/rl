<?php 
$upload_services[] = "filejungle.com";
$max_file_size["filejungle.com"] = 2048;
$page_upload["filejungle.com"] = "filejungle.com.php";
?>