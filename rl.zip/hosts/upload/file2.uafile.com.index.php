<?php
$upload_services[]="file2.uafile.com";
$max_file_size["file2.uafile.com"]=750;
$page_upload["file2.uafile.com"] = "file2.uafile.com.php";  
?>