<?
$upload_services[]="archiv.to";
$max_file_size["archiv.to"]=2000;
$page_upload["archiv.to"] = "archiv.to.php";
?>