<?php
$upload_services[]="freakshare.net_member";
$max_file_size["freakshare.net_member"]=2048;
$page_upload["freakshare.net_member"] = "freakshare.net_member.php";  
?>
