<?php
$upload_services[]="filereactor.com_member";
$max_file_size["filereactor.com_member"]=2048;
$page_upload["filereactor.com_member"] = "filereactor.com_member.php";  
?>