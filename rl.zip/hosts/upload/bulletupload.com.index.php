﻿<?php 
$upload_services[]="bulletupload.com";
$max_file_size["bulletupload.com"]=1024;
$page_upload["bulletupload.com"] = "bulletupload.com.php";  
?>
