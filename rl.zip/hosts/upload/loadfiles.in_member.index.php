<?php
$upload_services[]="loadfiles.in_member";
$max_file_size["loadfiles.in_member"]=2000;
$page_upload["loadfiles.in_member"] = "loadfiles.in_member.php";
?>
