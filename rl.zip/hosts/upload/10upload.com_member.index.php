﻿<?php 
$upload_services[]="10upload.com_member";
$max_file_size["10upload.com_member"]=1024;
$page_upload["10upload.com_member"] = "10upload.com_member.php";  
?>