<?php
$upload_services[]="4ppl.ru";
$max_file_size["4ppl.ru"]=100;
$page_upload["4ppl.ru"] = "4ppl.ru.php";  
?>