<?php 
$upload_services[]="lumfile.com";
$max_file_size["lumfile.com"]=3072; //I'm not sure about this actually, but that's written in remote url upload :|
$page_upload["lumfile.com"] = "lumfile.com.php";
?>