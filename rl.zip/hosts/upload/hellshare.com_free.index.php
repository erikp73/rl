<?php
$upload_services[]="hellshare.com_free";
$max_file_size["hellshare.com_free"]=false;
$page_upload["hellshare.com_free"] = "hellshare.com_free.php";  
?>