<?php
$upload_services[]="glumbouploads.com";
$max_file_size["glumbouploads.com"] = 2048;
$page_upload["glumbouploads.com"] = "glumbouploads.com.php";  
?>