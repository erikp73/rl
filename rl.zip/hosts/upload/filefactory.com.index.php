<?php 
$upload_services[] = "filefactory.com";
$max_file_size["filefactory.com"] = 2000;
$page_upload["filefactory.com"] = "filefactory.com.php";
?>