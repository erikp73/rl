<?php
$upload_services[]="evilshare.com_free";
$max_file_size["evilshare.com_free"]=200;
$page_upload["evilshare.com_free"] = "evilshare.com_free.php";  
?>