﻿<?php 
$upload_services[]="filewinds.com_member";
$max_file_size["filewinds.com_member"]=1024;
$page_upload["filewinds.com_member"] = "filewinds.com_member.php";  
?>