<?
$upload_services[]="filezzz.com_member";
$max_file_size["filezzz.com_member"]=false;
$page_upload["filezzz.com_member"] = "filezzz.com_member.php";
?>