<?
$upload_services[]="megaftp.com_member";
$max_file_size["megaftp.com_member"]=1000;
$page_upload["megaftp.com_member"] = "megaftp.com_member.php";  
?>