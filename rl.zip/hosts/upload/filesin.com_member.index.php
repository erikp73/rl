﻿<?php 
$upload_services[]="filesin.com_member";
$max_file_size["filesin.com_member"]=100;
$page_upload["filesin.com_member"] = "filesin.com_member.php";  
?>
