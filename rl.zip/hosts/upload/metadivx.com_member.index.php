<?php
$upload_services[]="metadivx.com_member";
$max_file_size["metadivx.com_member"]=1000;
$page_upload["metadivx.com_member"] = "metadivx.com_member.php";  
?>