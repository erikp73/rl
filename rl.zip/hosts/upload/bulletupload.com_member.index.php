﻿<?php 
$upload_services[]="bulletupload.com_member";
$max_file_size["bulletupload.com_member"]=1024;
$page_upload["bulletupload.com_member"] = "bulletupload.com_member.php";  
?>
